﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CldFinalPoe.Models
{
    public class Transactions
    {
        [Key]
        public int TransactionId { get; set; }
        public int ProductId { get; set; }
        public string? UserId { get; set; }  // Add this property
        public decimal TotalAmount { get; set; }

        public DateTime TransactionDate { get; set; }

        // Navigation property to the associated product
        public MyWork? Product { get; set; }
        public string? Status { get; set; }
    }
}