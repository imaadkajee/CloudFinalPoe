﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CldFinalPoe.Models
{
    public class QueueMessages
    {
        [Key]
        public int Id { get; set; }
        public string? MessageText { get; set; }
        public DateTime EnqueuedTime { get; set; }
    }
}