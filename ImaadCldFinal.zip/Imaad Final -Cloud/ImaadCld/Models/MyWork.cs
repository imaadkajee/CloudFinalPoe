﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CldFinalPoe.Models
{
    public class MyWork
    {
        [Key]
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public decimal ProductPrice { get; set; }
        public string? ProductDescription { get; set; }
        public string? Category { get; set; }
        public bool Availability { get; set; }
        public string? ImagePath { get; set; }
    }
}