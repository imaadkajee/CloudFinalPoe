﻿using Microsoft.AspNetCore.Mvc;

namespace CldFinalPoe.Models
{
    public class MyWorkViewModel
    {
        public MyWork? Product { get; set; }
        public IEnumerable<string>? AvailableImages { get; set; }
        public string? SelectedImagePath { get; set; }
    }
}