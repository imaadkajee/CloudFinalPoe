﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CldFinalPoe.Models
{
    public class FileRecord
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(255)]
        public string FileName { get; set; }

        [Required]
        [MaxLength(500)]
        public string FilePath { get; set; }

        public DateTime UploadDate { get; set; }

        [MaxLength(100)]
        public string ContentType { get; set; }

        public long FileSize { get; set; }
    }
}

