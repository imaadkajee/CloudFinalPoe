﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CldFinalPoe.Models;

namespace CldFinalPoe.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<CldFinalPoe.Models.MyWork> MyWork { get; set; } = default!;
        public DbSet<CldFinalPoe.Models.Transactions> Transactions { get; set; } = default!;
        public DbSet<FileRecord> FileRecords { get; set; }
        public DbSet<QueueMessages> QueueMessages { get; set; }

        // Override OnModelCreating to configure decimal properties with precision and scale
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure ProductPrice column in MyWork entity with precision and scale
            modelBuilder.Entity<MyWork>()
                .Property(m => m.ProductPrice)
                .HasColumnType("decimal(18,2)");  // Set precision 18 and scale 2 (you can adjust as needed)

            // Configure TotalAmount column in Transactions entity with precision and scale
            modelBuilder.Entity<Transactions>()
                .Property(t => t.TotalAmount)
                .HasColumnType("decimal(18,2)");  // Set precision 18 and scale 2 (you can adjust as needed)
        }
    }
}