﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using ImaadFinalCld.Models;
using Microsoft.AspNetCore.Authorization;

namespace ImaadFinalCld.Controllers
{
    public class MyWorksController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MyWorksController(ApplicationDbContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Index()
        {
            return View(await _context.MyWork.ToListAsync());
        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var myWork = await _context.MyWork
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (myWork == null)
            {
                return NotFound();
            }

            return View(myWork);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            var model = new MyWorkViewModel
            {
                Product = new MyWork(),
                AvailableImages = GetImagesFromDirectory()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(MyWorkViewModel model)
        {
            if (ModelState.IsValid)
            {
                _context.Add(model.Product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            model.AvailableImages = GetImagesFromDirectory();
            return View(model);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var myWork = await _context.MyWork.FindAsync(id);
            if (myWork == null)
            {
                return NotFound();
            }

            var model = new MyWorkViewModel
            {
                Product = myWork,
                AvailableImages = GetImagesFromDirectory()
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, MyWorkViewModel model)
        {
            if (id != model.Product.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    model.Product.ImagePath = model.SelectedImagePath;

                    _context.Update(model.Product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MyWorkExists(model.Product.ProductId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            model.AvailableImages = GetImagesFromDirectory();
            return View(model);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var myWork = await _context.MyWork
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (myWork == null)
            {
                return NotFound();
            }

            return View(myWork);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var myWork = await _context.MyWork.FindAsync(id);
            if (myWork != null)
            {
                _context.MyWork.Remove(myWork);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MyWorkExists(int id)
        {
            return _context.MyWork.Any(e => e.ProductId == id);
        }

        private IEnumerable<string> GetImagesFromDirectory()
        {
            var imagesPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images");
            var imageFiles = Directory.GetFiles(imagesPath)
                                      .Select(Path.GetFileName)
                                      .Select(fileName => $"/images/{fileName}");
            return imageFiles;
        }
    }
}
