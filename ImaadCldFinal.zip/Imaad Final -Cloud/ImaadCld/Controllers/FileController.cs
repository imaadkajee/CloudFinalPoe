﻿using Microsoft.AspNetCore.Mvc;
using ImaadFinalCld.Data;
using ImaadFinalCld.Models;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace ImaadFinalCld.Controllers
{
    public class FileController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly string _fileStoragePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/files");

        public FileController(ApplicationDbContext context)
        {
            _context = context;

            // Ensure the file storage directory exists
            if (!Directory.Exists(_fileStoragePath))
            {
                Directory.CreateDirectory(_fileStoragePath);
            }
        }

        public async Task<IActionResult> Index()
        {
            var files = await _context.FileRecords.ToListAsync();
            return View(files);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                TempData["ErrorMessage"] = "No document uploaded. Please select a file to upload.";
                return RedirectToAction("Index");
            }

            var filePath = Path.Combine(_fileStoragePath, file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // Create and save the file record
            var fileRecord = new FileRecord
            {
                FileName = file.FileName,
                FilePath = filePath,
                ContentType = file.ContentType,
                FileSize = file.Length,
                UploadDate = DateTime.UtcNow
            };
            _context.FileRecords.Add(fileRecord);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Document successfully uploaded.";
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Download(int id)
        {
            var fileRecord = await _context.FileRecords.FindAsync(id);

            if (fileRecord == null)
            {
                TempData["ErrorMessage"] = "File not found.";
                return RedirectToAction("Index");
            }

            var filePath = fileRecord.FilePath;

            if (!System.IO.File.Exists(filePath))
            {
                TempData["ErrorMessage"] = "File not found in storage.";
                return RedirectToAction("Index");
            }

            var memory = new MemoryStream();
            using (var stream = new FileStream(filePath, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;

            return File(memory, fileRecord.ContentType, fileRecord.FileName);
        }
    }
}

