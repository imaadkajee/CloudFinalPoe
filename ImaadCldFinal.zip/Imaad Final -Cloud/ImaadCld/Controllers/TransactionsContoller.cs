﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ImaadFinalCld.Data;
using ImaadFinalCld.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace ImaadFinalCld.Controllers
{

    public class TransactionsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TransactionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.Identity.Name;

            if (User.IsInRole("Admin"))
            {
                var allTransactions = await _context.Transactions.ToListAsync();
                return View(allTransactions);
            }
            else
            {
                var userTransactions = await _context.Transactions
                    .Where(t => t.UserId == userId)
                    .ToListAsync();

                return View(userTransactions);
            }
        }

        public async Task<IActionResult> Create(int productId)
        {
            var product = await _context.MyWork.FindAsync(productId);
            if (product == null || !product.Availability)
            {
                return NotFound();
            }

            var userId = User.Identity.Name;

            var userTransaction = new Transactions
            {
                ProductId = productId,
                UserId = userId,
                TransactionDate = DateTime.Now,
                TotalAmount = product.ProductPrice,
                Status = "Processing" // Set default status to "Processing"
            };

            _context.Add(userTransaction);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", "Transactions", new { id = userTransaction.TransactionId });
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var transaction = await _context.Transactions
                .FirstOrDefaultAsync(m => m.TransactionId == id);
            if (transaction == null)
            {
                return NotFound();
            }

            return View(transaction);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction == null)
            {
                return NotFound();
            }

            // Populate the dropdown list for ProductId
            ViewBag.ProductId = new SelectList(_context.MyWork, "ProductId", "ProductName", transaction.ProductId);

            return View(transaction);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("TransactionId,ProductId,UserId,TransactionDate,TotalAmount,Status")] Transactions transaction)
        {
            if (id != transaction.TransactionId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(transaction);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TransactionExists(transaction.TransactionId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(transaction);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmOrder(int transactionId, string cardNumber, string cardHolderName, string expiryDate, string cvv)
        {
            if (ModelState.IsValid)
            {
                if (IsValidCardDetails(cardNumber, cardHolderName, expiryDate, cvv))
                {
                    var transaction = await _context.Transactions.FirstOrDefaultAsync(t => t.TransactionId == transactionId);
                    if (transaction == null)
                    {
                        return NotFound();
                    }

                    // Assuming you have logic to process the transaction here
                    // For example, mark the transaction as confirmed, save changes, etc.
                    // Add your custom processing logic here

                    transaction.Status = "Processing"; // Update status to "Processed"
                    await _context.SaveChangesAsync();

                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid card details");
                }
            }

            var transactionDetails = await _context.Transactions.FirstOrDefaultAsync(t => t.TransactionId == transactionId);
            if (transactionDetails == null)
            {
                return NotFound();
            }
            return View("Details", transactionDetails);
        }

        private bool IsValidCardDetails(string cardNumber, string cardHolderName, string expiryDate, string cvv)
        {
            // Implement your validation logic here
            // Example validation (for demonstration purposes only):
            return !string.IsNullOrEmpty(cardNumber) &&
                   !string.IsNullOrEmpty(cardHolderName) &&
                   DateTime.TryParse(expiryDate, out _) &&
                   !string.IsNullOrEmpty(cvv) && cvv.Length == 3;
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var transaction = await _context.Transactions
                .FirstOrDefaultAsync(m => m.TransactionId == id);
            if (transaction == null)
            {
                return NotFound();
            }

            return View(transaction);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction == null)
            {
                return NotFound();
            }

            _context.Transactions.Remove(transaction);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TransactionExists(int id)
        {
            return _context.Transactions.Any(e => e.TransactionId == id);
        }
    }
}

