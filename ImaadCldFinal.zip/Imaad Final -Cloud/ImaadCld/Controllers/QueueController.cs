﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ImaadFinalCld.Models;
using System.Linq;
using System.Threading.Tasks;
using System;
using Microsoft.EntityFrameworkCore;

namespace ImaadFinalCld.Controllers
{
    public class QueueController : Controller
    {
        private readonly ApplicationDbContext _context;

        public QueueController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Enqueue(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                ViewBag.ErrorMessage = "Message cannot be empty.";
                return View("Index");
            }

            try
            {
                // Save the message to the database as an "enqueued" message
                var queueMessage = new QueueMessages
                {
                    MessageText = message,
                    EnqueuedTime = DateTime.UtcNow
                };

                // Add and save the new message
                _context.QueueMessages.Add(queueMessage);
                await _context.SaveChangesAsync();

                ViewBag.SuccessMessage = "Message sent to the queue successfully!";
            }
            catch (Exception ex)
            {
                // Log the actual error message to help troubleshoot
                Console.WriteLine("Error: " + ex.Message);
                ViewBag.ErrorMessage = "Failed to send the message. Please try again.";
            }

            return View("Index");
        }

        public async Task<IActionResult> Dequeue()
        {
            // Ensure EF Core is referenced properly to use ToListAsync
            var messages = await _context.QueueMessages
                                         .OrderBy(m => m.EnqueuedTime)
                                         .ToListAsync();

            if (messages.Any())
            {
                return View(messages);
            }

            ViewBag.ErrorMessage = "No messages found.";
            return View();
        }
    }
}

